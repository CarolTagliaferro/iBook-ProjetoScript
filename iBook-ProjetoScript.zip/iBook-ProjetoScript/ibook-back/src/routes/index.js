const express = require('express')
const clientes = require('./clientesRoute.js')
const restaurantes = require('./restaurantesRoute.js')
const itens = require('./itensRoute.js')

module.exports = app => {
    app.use(
        express.json(),
        clientes,
        restaurantes,
        itens
    );
};