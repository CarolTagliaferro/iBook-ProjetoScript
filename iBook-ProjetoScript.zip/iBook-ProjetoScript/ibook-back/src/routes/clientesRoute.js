const {Router} = require('express');
const ClienteController = require('../controllers/ClienteController.js');
const ReservaController = require('../controllers/ReservaController.js');
const authMiddleware = require('../middleware/authMiddleware');

const clienteController = new ClienteController();
const reservaController = new ReservaController()
const router = Router()

router.post('/cliente', (req, res) => clienteController.create(req, res));
router.post('/cliente/login', (req, res) => clienteController.doLogin(req, res));

router.get('/clientes', authMiddleware, (req, res) => clienteController.getAll(req, res));
router.get('/cliente/:id', authMiddleware, (req, res) => clienteController.getByPk(req, res));

router.delete('/cliente/:id', authMiddleware, (req, res) => clienteController.delete(req, res));
router.put('/cliente/:id', authMiddleware, (req, res) => clienteController.update(req, res));

//Reserva

router.post('/cliente/reserva', authMiddleware, (req, res) => reservaController.create(req, res));

router.get('/reservas', authMiddleware, (req, res) => reservaController.getAll(req, res));

router.get('/cliente/:id/reservas', authMiddleware, (req, res) => reservaController.getByCliente(req, res));

router.delete('/cliente/reserva/:id', authMiddleware, (req, res) => reservaController.delete(req, res));

module.exports = router;