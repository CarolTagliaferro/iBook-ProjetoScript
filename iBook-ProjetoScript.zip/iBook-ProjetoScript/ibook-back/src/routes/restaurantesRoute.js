const {Router} = require('express');
const RestauranteController = require('../controllers/RestauranteController.js');
const CardapioController = require('../controllers/CardapioController.js');
const CategoriaController = require('../controllers/CategoriaController.js');
const ReservaController = require('../controllers/ReservaController.js');
const authMiddleware = require('../middleware/authMiddleware');

const restauranteController = new RestauranteController();

//Restaurante CRUD
const router = Router()

router.get('/restaurantes', (req, res) => restauranteController.getAll(req, res));
router.get('/restaurante/:id',  (req, res) => restauranteController.getByPk(req, res));

router.post('/restaurante', (req, res) => restauranteController.create(req, res));
router.post('/restaurante/login', (req, res) => restauranteController.doLogin(req, res));

router.delete('/restaurante/:id', authMiddleware, (req, res) => restauranteController.delete(req, res));

router.put('/restaurante/:id', authMiddleware, (req, res) => restauranteController.update(req, res));

//Cardapio

const cardapioController = new CardapioController();

router.get('/restaurante/:id/cardapio', (req, res) => cardapioController.getCardapioItens(req, res));

//Categoria

const categoriaController = new CategoriaController();

router.get('/item/categorias', authMiddleware, (req, res) => categoriaController.getAll(req, res));

module.exports = router;

//Reserva

const reservaController = new ReservaController()

router.get('restaurante/:id/reservas', authMiddleware, (req, res) => reservaController.getByRestaurante(req, res));
