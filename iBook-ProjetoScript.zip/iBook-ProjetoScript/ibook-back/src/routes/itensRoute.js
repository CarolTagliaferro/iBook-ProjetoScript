const {Router} = require('express');
const ItensController = require('../controllers/ItensController.js');
const authMiddleware = require('../middleware/authMiddleware.js');

const itensController = new ItensController();
const router = Router()

router.post('/item', authMiddleware, (req, res) => itensController.create(req, res));

router.get('/itens', authMiddleware, (req, res) => itensController.getAll(req, res));
router.get('/item/:id', authMiddleware, (req, res) => itensController.getByPk(req, res));

router.delete('/item/:id', authMiddleware, (req, res) => itensController.delete(req, res));
router.put('/item/:id', authMiddleware, (req, res) => itensController.update(req, res));

module.exports = router;