const express = require('express');
const routes = require('./routes')
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();

app.use(cors({
    origin: 'http://localhost:3000' // Substitua pelo seu domínio React
}));

app.use(bodyParser.json());

routes(app);

module.exports = app;