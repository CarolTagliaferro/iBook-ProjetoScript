'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
	async up(queryInterface, Sequelize) {

		await queryInterface.createTable('clientes', {
			id: {
				allowNull: false,
				autoIncrement: true,
				primaryKey: true,
				type: Sequelize.INTEGER
			},
			Nome: {
				type: Sequelize.STRING
			},
			Email: {
				type: Sequelize.STRING
			},
			Telefone: {
				type: Sequelize.STRING
			},
			Senha: {
				type: Sequelize.STRING
			},
			CPF: {
				type: Sequelize.STRING
			},
			createdAt: {
				allowNull: false,
				type: Sequelize.DATE
			},
			updatedAt: {
				allowNull: false,
				type: Sequelize.DATE
			}
		});

		await queryInterface.createTable('categorias', {
			id: {
				type: Sequelize.INTEGER,
				primaryKey: true,
				autoIncrement: true
			},
			Nome: {
				type: Sequelize.STRING
			},
			createdAt: {
				type: Sequelize.DATE,
				allowNull: false
			},
			updatedAt: {
				type: Sequelize.DATE,
				allowNull: false
			}
		});
	  
		await queryInterface.createTable('cardapios', {
			id: {
				allowNull: false,
				autoIncrement: true,
				primaryKey: true,
				type: Sequelize.INTEGER
			},
			Nome: {
				type: Sequelize.STRING
			},
			RestauranteID: {
			  type: Sequelize.INTEGER,
			  allowNull: false,
			  references: {
				model: 'Restaurante',
				key: 'id'
			  },
			  onUpdate: 'CASCADE',
			  onDelete: 'CASCADE'
			},
			createdAt: {
				allowNull: false,
				type: Sequelize.DATE
			},
			updatedAt: {
				allowNull: false,
				type: Sequelize.DATE
			}
		});
			
		await queryInterface.createTable('itens', {
			id: {
				type: Sequelize.INTEGER,
				primaryKey: true,
				autoIncrement: true
			},
			Nome: {
				type: Sequelize.STRING
			},
			Descricao: {
				type: Sequelize.STRING
			},
			Preco: {
				type: Sequelize.FLOAT
			},
			Ativo: {
				type: Sequelize.BOOLEAN,
				defaultValue: true
			},
			CardapioID: {
				type: Sequelize.INTEGER,
				references: {
					model: 'Cardapio',
					key: 'id'
				},
				onDelete: 'CASCADE'
			},
			CategoriaID: {
				type: Sequelize.INTEGER,
				references: {
					model: 'Categoria',
					key: 'id'
				},
				onDelete: 'CASCADE'
			},
			createdAt: {
				type: Sequelize.DATE,
				allowNull: false
			},
			updatedAt: {
				type: Sequelize.DATE,
				allowNull: false
			}
		});

		await queryInterface.createTable('restaurantes', {
			id: {
				allowNull: false,
				autoIncrement: true,
				primaryKey: true,
				type: Sequelize.INTEGER
			},
			Nome: {
				type: Sequelize.STRING
			},
			Endereco: {
				type: Sequelize.STRING
			},
			Telefone: {
				type: Sequelize.STRING
			},
			Email: {
				type: Sequelize.STRING
			},
			CNPJ: {
				type: Sequelize.STRING
			},
			Senha: {
				type: Sequelize.STRING
			},
			createdAt: {
				allowNull: false,
				type: Sequelize.DATE
			},
			updatedAt: {
				allowNull: false,
				type: Sequelize.DATE
			}
		});

		await queryInterface.createTable('reservas', {
			id: {
			  type: Sequelize.INTEGER,
			  primaryKey: true,
			  autoIncrement: true
			},
			Data: {
				type: Sequelize.DATE
			},
			Horario: {
			  type: Sequelize.TIME
			},
			NumeroPessoas: {
				type: Sequelize.INTEGER
			},
			ClienteId: {
			  type: Sequelize.INTEGER,
			  references: {
				model: 'Cliente',
				key: 'id'
			  },
			  onDelete: 'CASCADE'
			},
			RestauranteId: {
			  type: Sequelize.INTEGER,
			  references: {
				model: 'Restaurante',
				key: 'id'
			  },
			  onDelete: 'CASCADE'
			},
			createdAt: {
			  type: Sequelize.DATE,
			  allowNull: false
			},
			updatedAt: {
			  type: Sequelize.DATE,
			  allowNull: false
			}
		});

	},

	async down(queryInterface, Sequelize) {
		await queryInterface.dropTable('reservas');
		await queryInterface.dropTable('restaurantes');
		await queryInterface.dropTable('itens');
		await queryInterface.dropTable('cardapios');
		await queryInterface.dropTable('categorias');
		await queryInterface.dropTable('clientes');
	}
};
