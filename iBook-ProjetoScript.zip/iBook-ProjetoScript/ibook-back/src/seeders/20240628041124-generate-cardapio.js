'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Itens', [
			{
        CardapioID: 1,
        CategoriaID: 1,
        Nome: "Salada Ceasar",
        Descricao: "Uma salada muito gostosa",
        Preco: 15,
        Ativo: true,
        createdAt: new Date(), updatedAt: new Date()
    },
    {
      CardapioID: 1,
      CategoriaID: 2,
      Nome: "Salmão grelhado",
      Descricao: "Um salmão muito gostoso",
      Preco: 50,
      Ativo: true,
      createdAt: new Date(), updatedAt: new Date()
    },
    {
      CardapioID: 1,
      CategoriaID: 3,
      Nome: "Sorvete de limão",
      Descricao: "Um Sorvete de limão muito gostoso",
      Preco: 9.9,
      Ativo: true,
      createdAt: new Date(), updatedAt: new Date()
    },
    {
      CardapioID: 1,
      CategoriaID: 3,
      Nome: "Suco de laranja",
      Descricao: "Um Suco de laranja muito gostoso",
      Preco: 12,
      Ativo: true,
      createdAt: new Date(), updatedAt: new Date()
    }
		]);
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Itens', null, {});
  }
};
