'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Itens extends Model {
    static associate(models) {
      Itens.belongsTo(models.Cardapio, { foreignKey: 'CardapioID' });
      Itens.belongsTo(models.Categoria, { foreignKey: 'CategoriaID', as: 'categoria' });
    }
  }
  Itens.init({
    CardapioID: DataTypes.INTEGER,
    CategoriaID: DataTypes.INTEGER,
    Nome: DataTypes.STRING,
    Descricao: DataTypes.TEXT,
    Preco: DataTypes.DECIMAL,
    Ativo: DataTypes.BOOLEAN
  }, {
    sequelize,
    modelName: 'Itens',
    tableName: 'itens'
  });
  return Itens;
};