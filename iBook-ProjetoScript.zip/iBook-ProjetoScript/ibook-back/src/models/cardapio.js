'use strict';
const {
	Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
	class Cardapio extends Model {
		static associate(models) {
			Cardapio.belongsTo(models.Restaurante, { foreignKey: 'RestauranteID' });
			Cardapio.hasMany(models.Itens, {
				foreignKey: 'CardapioID',
				as: 'itensCardapio'
			});
		}
	}
	Cardapio.init({
		Nome: DataTypes.STRING,
		RestauranteID: DataTypes.INTEGER,
	}, {
		sequelize,
		modelName: 'Cardapio',
		tableName: 'cardapios'
	});
	return Cardapio;
};