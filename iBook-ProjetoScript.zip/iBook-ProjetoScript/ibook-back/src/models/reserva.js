'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Reserva extends Model {
    static associate(models) {
      Reserva.belongsTo(models.Cliente, { foreignKey: 'ClienteID', as: 'cliente' });
      Reserva.belongsTo(models.Restaurante, { foreignKey: 'RestauranteID', as: 'restaurante' });
    }
  }
  Reserva.init({
    ClienteID: DataTypes.INTEGER,
    RestauranteID: DataTypes.INTEGER,
    Data: DataTypes.DATE,
    Horario: DataTypes.TIME,
    NumeroPessoas: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Reserva',
    tableName: 'reservas'
  });
  return Reserva;
};