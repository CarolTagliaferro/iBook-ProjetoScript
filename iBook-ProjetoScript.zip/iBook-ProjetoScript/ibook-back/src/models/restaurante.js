'use strict';
const {
	Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
	class Restaurante extends Model {
		static associate(models) {
			Restaurante.hasOne(models.Cardapio, { foreignKey: 'RestauranteID' });
			Restaurante.hasMany(models.Reserva, { foreignKey: 'RestauranteID', as:'restaurante' });
		}
	}
	Restaurante.init({
		Nome: DataTypes.STRING,
		Endereco: DataTypes.STRING,
		Telefone: DataTypes.STRING,
		Email: DataTypes.STRING,
		CNPJ: DataTypes.STRING,
		Senha: DataTypes.STRING
	}, {
		sequelize,
		modelName: 'Restaurante',
		tableName: 'restaurantes'
	});
	return Restaurante;
};