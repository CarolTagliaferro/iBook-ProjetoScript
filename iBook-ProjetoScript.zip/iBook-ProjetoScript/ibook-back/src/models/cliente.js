'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Cliente extends Model {
    static associate(models) {
      Cliente.hasMany(models.Reserva, { foreignKey: 'ClienteID' });
    }
  }
  Cliente.init({
    Nome: DataTypes.STRING,
    Email: DataTypes.STRING,
    Telefone: DataTypes.STRING,
    Senha: DataTypes.STRING,
    CPF: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Cliente',
    tableName: 'clientes'
  });
  return Cliente;
};