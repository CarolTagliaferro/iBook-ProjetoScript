const Services = require('./Services.js');

class ItensServices extends Services{
    constructor(){
        super('Itens');
    }
}

module.exports = ItensServices;