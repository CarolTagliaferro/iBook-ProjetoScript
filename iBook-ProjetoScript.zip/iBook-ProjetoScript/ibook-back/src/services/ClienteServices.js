const Services = require('./Services.js');

class ClienteServices extends Services{
    constructor(){
        super('Cliente');
    }

    async getByEmail(email) {
        const cliente = await super.getByCondition({where: {Email: email}});
        return cliente;
    }
}

module.exports = ClienteServices;