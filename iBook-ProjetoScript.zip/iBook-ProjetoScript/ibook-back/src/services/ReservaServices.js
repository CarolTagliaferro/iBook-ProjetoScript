const Services = require('./Services.js');

class ReservaServices extends Services{
    constructor(){
        super('Reserva');
    }
}

module.exports = ReservaServices;