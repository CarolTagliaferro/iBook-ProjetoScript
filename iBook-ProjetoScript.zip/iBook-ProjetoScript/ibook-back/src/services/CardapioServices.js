const Services = require('./Services.js');
const { Itens, Categoria } = require('../models');

class CardapioServices extends Services{
    constructor(){
        super('Cardapio');
    }

    async getItensDoCardapio(restauranteId) {
        const cardapio = await super.getByCondition({
            where: {
                RestauranteId: restauranteId
            }, 
            include: [
                {
                    model: Itens,
                    as: 'itensCardapio',
                    include: [
                        {
                            model: Categoria,
                            attributes: ['nome'], 
                            as: 'categoria'
                        }
                    ]
                }
            ]
        });
        
        return cardapio;
    }
}

module.exports = CardapioServices;