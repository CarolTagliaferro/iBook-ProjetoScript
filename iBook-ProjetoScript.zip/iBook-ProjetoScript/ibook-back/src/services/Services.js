const dataSource = require('../models');

class Services {
	constructor(nomeDoModel) {
		this.model = nomeDoModel;
	}

    async getAll(){
        return dataSource[this.model].findAll();
    }

    async getByPk(id){
        return dataSource[this.model].findByPk(id);
    }

    async getByCondition(condition){
        return dataSource[this.model].findOne(condition);
    }

    async getAllByCondition(condition){
        return dataSource[this.model].findAll(condition);
    }

    async create(data){
        return dataSource[this.model].create(data);
    }

    async update(data, id){
        const listadeRegistrosAtualizados = dataSource[this.model].update(data, {
			where: { id: id }
		});
		if (listadeRegistrosAtualizados[0] === 0) {
			return false;
		}
		return true;
    }

    async delete(id) {
		return dataSource[this.model].destroy({ where: { id: id } });
	}
}

module.exports = Services;