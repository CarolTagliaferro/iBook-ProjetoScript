const Services = require('./Services.js');

class CategoriaServices extends Services{
    constructor(){
        super('Categoria');
    }

    async getByEmail(email) {
        const cliente = await super.getByCondition({where: {Email: email}});
        return cliente;
    }
}

module.exports = CategoriaServices;