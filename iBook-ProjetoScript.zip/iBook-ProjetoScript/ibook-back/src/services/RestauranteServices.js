const Services = require('./Services.js');

class RestauranteServices extends Services{
    constructor(){
        super('Restaurante');
    }

    async getByEmail(email) {
        const restaurante = await super.getByCondition({where: {Email: email}});
        return restaurante;
    }
}

module.exports = RestauranteServices;