const Controller = require('./Controller.js');
const ClienteServices = require('../services/ClienteServices.js');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const clienteServices = new ClienteServices();

class ClienteController extends Controller {
    constructor(){
        super(clienteServices)
    }

    async create(req, res){
        try {
            const { Email, Senha } = req.body;
            const existingCliente = await clienteServices.getByEmail(Email);
            
            if (existingCliente) return res.status(400).json({ error: 'Cliente com esse email já existe!' });

            const salt = bcrypt.genSaltSync();
            req.body.Senha = bcrypt.hashSync(Senha, salt);

            return super.create(req, res);
        } catch (error) {
            return res.status(500).json({'error' : error.message});
        }
    }

    async doLogin(req, res){
        try {
            const { Email, Senha } = req.body;
            const existingCliente = await clienteServices.getByEmail(Email);

            if (!existingCliente) return res.status(400).json({'InvalidLogin' : 'Email ou Senha inválidos'});

            const validPassword = bcrypt.compareSync(Senha, existingCliente.Senha);

            if(validPassword){
                const token = jwt.sign({ id: existingCliente.id }, 'chave-secreta', { expiresIn: '1h' });

                return res.json({token: token, cliente: existingCliente});
            }else{
                return res.status(400).json({'InvalidLogin' : 'Email ou Senha inválidos'});
            }

        } catch (error) {
            return res.status(500).json({'error' : error.message});
        }
    }
}

module.exports = ClienteController;