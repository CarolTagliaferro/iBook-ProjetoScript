const Controller = require('./Controller.js');
const ReservaServices = require('../services/ReservaServices.js');
const {  Cliente, Restaurante } = require('../models');

const reservaServices = new ReservaServices();

class ReservaController extends Controller {
    constructor(){
        super(reservaServices)
    }

    async getByCliente(req, res){
        const { id } = req.params;

        const condition = {
            where: { ClienteID: id },
            include: [
                {
                    model: Restaurante,
                    as: 'restaurante',
                    attributes: ['nome']
                },
                {
                    model: Cliente,
                    as: 'cliente',
                    attributes: ['nome']
                }
            ]
        }

        const reservas = await reservaServices.getAllByCondition(condition);

        return res.status(200).json(reservas);
    }

    async getByRestaurante(req, res){
        const { id } = req.params;

        const condition = {
            where: { RestauranteID: id },
            include: [
                {
                    model: Restaurante,
                    as: 'restaurante',
                    attributes: ['nome']
                },
                {
                    model: Cliente,
                    as: 'cliente',
                    attributes: ['nome']
                }
        ]}

        const reservas = await reservaServices.getAllByCondition(condition);

        return res.status(200).json(reservas);
    }

}

module.exports = ReservaController;