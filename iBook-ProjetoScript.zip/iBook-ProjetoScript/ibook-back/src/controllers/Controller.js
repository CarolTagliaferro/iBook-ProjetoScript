class Controller {
    constructor(entidadeService) {
        this.entidadeService = entidadeService;
    }

    async getAll(req, res){
        try {
            const data = await this.entidadeService.getAll();
            if(data.length === 0) return res.status(400).message({'message':'No data was found'});
            return res.status(200).json(data);
        } catch (error) {
            return res.status(500).json(error);
        }
    }

    async getByPk(req, res){
        try {
            const { id } = req.params;
            const data = await this.entidadeService.getByPk(Number(id));
            if(data.length === 0) return res.status(400).message({'message':'No data was found'});
            return res.status(200).json(data);
        } catch (error) {
            return res.status(500).json(error);
        }
    }

    async create(req, res){
        try {
            const newData = req.body;
            if(newData == null || newData == undefined || newData == '') return res.status(400).message({'message':'Empty body to create the data'});
            const data = await this.entidadeService.create(newData);
            return res.status(200).json(data);
        } catch (error) {
            return res.status(500).json(error);
        }
    }

    async update(req, res){
        try {
            const { id } = req.params;
            const data = req.body;
            const isUpdated = await this.entidadeService.update(data, Number(id));
            if(!isUpdated) return res.status(400).json({ mensagem: 'Registro não atualizado!' });
            return res.status(200).json({ mensagem: 'Registro atualizado com sucesso' });
        } catch (error) {
            return res.status(500).json(error);
        }
    }

    async delete(req, res){
        try {
            const { id } = req.params;
            await this.entidadeService.delete(Number(id));
            return res.status(200).json({ mensagem: `Id ${id} deletado` });
        } catch (error) {
            return res.status(500).json(error);
        }
    }

}

module.exports = Controller;