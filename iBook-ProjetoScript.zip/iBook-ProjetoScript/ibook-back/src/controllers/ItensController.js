const Controller = require('./Controller.js');
const ItensServices = require('../services/ItensServices.js');
const CardapioServices = require('../services/CardapioServices.js')
const CategoriaServices = require('../services/CategoriaServices.js')

const itensServices = new ItensServices();

class ItensController extends Controller {
    constructor(){
        super(itensServices)
    }

    async create(req, res){
        const { id } = req.params;
        const cardapio = new CardapioServices().getByCondition({where: { RestauranteID: id }});

        if(!cardapio) return res.status(400).json({ error: 'Este Restaurante não possui um cardápio.' });

        super.create(req, res);
    }
}

module.exports = ItensController;