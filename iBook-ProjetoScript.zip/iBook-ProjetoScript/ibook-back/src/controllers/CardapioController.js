const Controller = require('./Controller.js');
const CardapioServices = require('../services/CardapioServices.js');

const cardapioServices = new CardapioServices();

class CardapioController extends Controller {
    constructor(){
        super(cardapioServices)
    }

    async getCardapioItens(req, res){
        try {
            const { id } = req.params;
            const itensDoCardapio = await cardapioServices.getItensDoCardapio(id);
            return res.status(200).json(itensDoCardapio);
        } catch (error) {
            return res.status(500).json({'error' : error.message});
        }
    }
}

module.exports = CardapioController;