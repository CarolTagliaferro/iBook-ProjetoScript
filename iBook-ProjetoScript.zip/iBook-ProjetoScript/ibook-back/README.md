# Backend do Projeto iBook

Este projeto de backend foi desenvolvido para suportar um sistema de reservas de restaurantes. Utiliza SQLite como banco de dados, Express.js como framework web, Node.js para o ambiente de execução JavaScript no servidor, e APIs para comunicação entre o frontend e o backend.

## Tecnologias Utilizadas

- Node.js
- Express.js
- SQLite
- JavaScript

## Configuração

1. **Instalação das Dependências:**

   - npm install

2. **Execução do Servidor:**

   - npm run dev

3. **Estrutura do projeto:**

Na pasta models temos as estruturas dos objetos utilizados pelo Banco de dados e pela API.

    - Cardapio (por ID do restaurante)
    - Categoria (categoria dos itens do cardapio)
    - Cliente
    - Itens (itens do cardapio por ID de categoria e restaurante)
    - Reserva (É feita pelo ID do cliente e do restaurante)
    - Restaurante

Conseguimos realizar cadastro de novos clientes, editar informações do cliente, consultar cardapios e realizar/deletar reservas em restaurantes.

Para conseguir visualizar perfil e realizar reservas o cliente necessita estar logado!

# É necessario executar o backend com o comando dentro da pasta ibook-back e o frontend dentro da pasta ibook-front
