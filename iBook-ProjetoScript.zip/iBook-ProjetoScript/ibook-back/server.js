const app = require('./src/app.js');

const PORT = 3030;

app.listen(PORT, () => {
  console.log('servidor escutando!');
});
