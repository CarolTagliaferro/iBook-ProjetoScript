# Frontend do Projeto iBook

Este projeto frontend foi desenvolvido para ser usado por clientes para gerenciar reservas de restaurantes. Utiliza React para o desenvolvimento da interface de usuário, Axios para fazer requisições HTTP para o backend, e Tailwind CSS para estilização.

## Tecnologias Utilizadas

- React
- Axios
- JavaScript
- Tailwind CSS

## Configuração

1. **Instalação das Dependências:**

   - npm install

2. **Execução do Aplicativo:**

   - npm start

3. **Funcionalidades Implementadas:**

- Visualização de restaurantes disponíveis.
- Visualização de detalhes do restaurante e menu.
- Criação de novas reservas.
- Visualização de reservas existentes.

## Estrutura de Pastas

- `src/`
- `components/` - Componentes React reutilizáveis.
- `pages/` - Páginas da aplicação (Home, Login, Restaurante, Cliente).
- `images/` - Imagens estáticas utilizadas no projeto.
- `api/` - Configuração e funções de requisições HTTP com Axios.
- `App.js` - Componente principal da aplicação React.
- `Routes` - Rotas definidas para aplicação

Na pagina de Login você consegue logar uma conta existente ou criar uma conta nova.
Na pagina Home você ira ver os cards com os restaurantes disponiveis, ao clicar no restaurante sera direcionado para tela com informações, cardapio
e o botão de efetuar reserva. Ao clicar em efetuar reserva você será direcionado para pagina de reserva onde vai escolher dia, horario e quantidade
de pessoas, depois que confirmar sua reserva estara pronta. Na aba reservas na header você pode ver todas reservas feitas com seu usuario e tambem
pode cancelar a reserva se preferir.
Na pagina de Perfil você consegue visualizar e alterar informações do seu cadastro.

# É necessario executar o backend com o comando dentro da pasta ibook-back e o frontend dentro da pasta ibook-front
