import React from 'react';
import restauranteImg from "../images/restauranteImg.jpg";
import { NavLink } from 'react-router-dom';

const CardRestaurante = ({ restaurante }) => {
  const { id, Nome, Endereco, Telefone, Email } = restaurante;

  return ( 
    <div className="bg-gray-100 shadow-md rounded-lg overflow-hidden max-w-full">
      <div className="flex">
        <div className="flex-shrink-0">
          <img className="object-cover h-full w-60 p-3" src={restauranteImg} alt={Nome} />
        </div>
        <div className="p-8">
          <div className="uppercase tracking-wide text-red-600 font-semibold">{Nome}</div>
          <p className="mt-2 text-gray-500 text-sm">{Endereco}</p>
          <p className="mt-2 text-gray-500 text-sm">{Telefone}</p>
          <p className="mt-2 text-gray-500 text-sm">{Email}</p>
          <div className="mt-4">
            <NavLink to={`/restauranteMenu/${id}`}>
              <button className="text-white bg-red-600 rounded-md hover:bg-red-500 py-2 px-4">Mais detalhes</button>
            </NavLink>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardRestaurante;
