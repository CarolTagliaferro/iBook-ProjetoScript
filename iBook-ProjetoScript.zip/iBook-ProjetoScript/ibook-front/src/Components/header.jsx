import React from 'react';
import logo from "../images/logo.png";
import { NavLink } from 'react-router-dom';

const Header = () => {
  const cliente = JSON.parse(sessionStorage.getItem('cliente'));
  const id = cliente ? cliente.id : '';

  return (
    <main>
      <header className='font-poppins border border-b bg-neve'>
        <div className='flex justify-between ml-12 mr-6 mt-3 mb-3'>
          <NavLink to="/">
            <div className='flex items-center'>
              <img src={logo} alt="logo" className='w-12 h-12' />
              <h1 className='font-semibold text-2xl pt-2 pl-1 text-red-600'>iBook</h1>
            </div>
          </NavLink>
          <div className='flex flex-1 justify-center items-center gap-24'>
            <NavLink to="/">
              <p className='hover:text-red-600'>Home</p>
            </NavLink>
            <NavLink to="/perfil">
              <p className='hover:text-red-600'>Perfil</p>
            </NavLink>
            <NavLink to={`/cliente/${id}/reservas`}>
              <p className='hover:text-red-600'>Reservas</p>
            </NavLink>
          </div>
          <div className='flex items-center ml-auto'>
            <NavLink to="/login">
              <button className='text-white bg-red-600 rounded-md hover:bg-red-500 py-1 px-3'>Login</button>
            </NavLink>
          </div>
        </div>
      </header>
    </main>
  );
}

export default Header;
