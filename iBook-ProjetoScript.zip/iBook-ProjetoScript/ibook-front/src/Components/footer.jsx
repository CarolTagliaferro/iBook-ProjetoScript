import React from 'react'
import { NavLink } from 'react-router-dom'
import { FaFacebookSquare, FaInstagram, FaPhoneAlt, FaTwitterSquare } from 'react-icons/fa'
import { AiOutlineMail } from "react-icons/ai";


const Footer = () => {
  return (
 <footer className='bg-neve border-t font-poppins'>
    <div className='my-4 mx-10'>
        <div className='text-center flex justify-between'>
            <NavLink to="/">
                <h1 className='text-3xl font-semibold text-red-600'>iBook.</h1>
            </NavLink>
            <div className='flex gap-10'>
            <div className='flex items-center'>
                <FaPhoneAlt className='text-lg'/>
                <span className='pl-3 italic'>01 2345 6789</span>
            </div>
            <div className='flex items-center'>
                <AiOutlineMail className='text-lg'/>
                <span className='pl-2 italic'>info-ibook@email.com</span>
            </div>
            </div>
            <div className='flex gap-4 justify-center'>
                <a href="https://www.facebook.com/" target='blank'>
                <FaFacebookSquare className='text-red-600 hover:text-red-700 text-2xl'/>
                </a>
                <a href="https://www.instagram.com/" target='blank'>
                <FaInstagram className='text-red-600 text-2xl hover:text-red-700'/>
                </a>
                <a href="https://twitter.com/" target='blank'>
                <FaTwitterSquare className='text-red-600 text-2xl hover:text-red-700'/>
                </a>
            </div>
        </div>
        <div className='border-t text-center text-gray-600 text-sm py-1 my-3'>
            <p>2024 iBook. All rights reserved.</p>
        </div>
    </div>
</footer>
  )
}

export default Footer
            
            
            