import React from 'react';
import Header from './Components/header.jsx';
import AppRouter from './Routes/router';
import Footer from './Components/footer.jsx';

function App() {
  return (
    <div className='flex flex-col min-h-screen'>
      <Header />
      <main className='flex-grow'>
      <AppRouter />
      </main>
      <Footer/>
    </div>
  );
}

export default App;
