import React from 'react'
import useFetchApi from '../../API/FetchApi'
import CardRestaurante from '../../Components/cardRestaurante';

const ListaRestaurantes = () => {
    const {restaurantes, loading, error} = useFetchApi ("http://localhost:3030/restaurantes")
    

    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;
  
 return (
    <div>
        {restaurantes.map(restaurante => (
        <div key={restaurante.id}>
          <CardRestaurante restaurante={restaurante} />
        </div>
      ))}
    </div>
  )
}

export default ListaRestaurantes