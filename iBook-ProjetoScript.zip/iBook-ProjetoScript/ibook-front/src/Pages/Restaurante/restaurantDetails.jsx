import React, { useState, useEffect } from 'react';
import { NavLink, useParams } from 'react-router-dom';
import bannerRes from "../../images/bannerRes.jpg";
import axios from 'axios';

const RestaurantDetails = () => {
  const { id } = useParams();
  const [restaurant, setRestaurant] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchRestaurantDetails = async () => {
      try {
        
        const response = await axios.get(`http://localhost:3030/restaurante/${id}`);
        if (response.status !== 200) {
          throw new Error('Failed to fetch restaurant details');
        }
        const restaurantData = response.data;

        
        const menuResponse = await axios.get(`http://localhost:3030/restaurante/${id}/cardapio`);
        if (menuResponse.status !== 200) {
          throw new Error('Failed to fetch restaurant menu');
        }
        const menuData = menuResponse.data;

        
        const restaurantWithMenu = {
          ...restaurantData,
          menu: menuData.itensCardapio  
        };

        setRestaurant(restaurantWithMenu);
      } catch (error) {
        console.error('Error fetching restaurant details:', error);
        setError('Failed to fetch restaurant details');
      } finally {
        setLoading(false);
      }
    };

    fetchRestaurantDetails();
  }, [id]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;
  if (!restaurant) return null;

  return (
    <main className='min-h-screen mx-72 mt-10 '>
      <div className="relative">
        <img src={bannerRes} alt={restaurant.Nome} className='w-full h-64 object-cover brightness-50' />
        <div className='absolute top-0 left-0 w-full h-64 flex items-center justify-center'>
          <h1 className='text-white text-6xl font-bold font-serif'>{restaurant.Nome}</h1>
        </div>
      </div>
      <div className="p-8 font-poppins">
        <div className='flex justify-between'>
          <div>
            <h2 className="text-2xl font-semibold mb-4">Sobre o Restaurante</h2>

            <p className="mb-2"><strong>Endereço:</strong> {restaurant.Endereco}</p>
            <p className="mb-6"><strong>Telefone:</strong> {restaurant.Telefone}</p>
          </div>
          <div>
            <NavLink to={`/reservar/${id}`}>
              <button className="px-8 py-2 rounded-md bg-red-600 hover:bg-red-500 text-white">Reservar Agora</button>
            </NavLink>
          </div>
        </div>
        <h2 className="text-3xl font-semibold my-4">Menu</h2>
        <div className="mb-8">
          {restaurant.menu && (
            <>
              {renderMenuCategory(restaurant.menu, 'Entradas', 'entrada')}
              {renderMenuCategory(restaurant.menu, 'Pratos Principais', 'pratoPrincipal')}
              {renderMenuCategory(restaurant.menu, 'Sobremesas', 'sobremesa')}
              {renderMenuCategory(restaurant.menu, 'Bebidas', 'bebida')}
            </>
          )}
        </div>
      </div>
    </main>
  );
};


const renderMenuCategory = (menu, categoryName, categoryKey) => {
  const categoryItems = menu.filter(item => item.categoria.nome === categoryName);

  return (
    <>
      <h3 className="text-xl font-semibold mb-2">{categoryName}</h3>
      <div className="grid gap-4 mb-4">
        {categoryItems.map((item, index) => (
          <div key={index} className="p-4 border rounded-md shadow-md bg-white">
            <h4 className="text-lg font-semibold">{item.Nome}</h4>
            <p>{item.Descricao}</p>
            <p className="text-red-600 font-semibold">R$ {item.Preco.toFixed(2)}</p>
          </div>
        ))}
      </div>
    </>
  );
};

export default RestaurantDetails;
