import React from 'react'
import ListaRestaurantes from '../Restaurante/listaRestaurantes.jsx'




const Home = () => {
  return (
    <div className='mx-72 mt-10 font-poppins'>
      <h1 className='font-semibold text-2xl mb-10'>Faça sua reserva</h1>
      <ListaRestaurantes/>
    </div>
  )
}

export default Home