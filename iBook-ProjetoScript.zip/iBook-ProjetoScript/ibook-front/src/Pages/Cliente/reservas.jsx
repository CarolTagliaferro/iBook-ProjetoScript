import React, { useState, useEffect } from 'react';
import axios from 'axios';
import bgReservas from "../../images/bgReservas.jpg";
import { useParams } from 'react-router-dom';

const MinhasReservas = () => {
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { id } = useParams(); 

  useEffect(() => {
    const fetchReservations = async () => {
      const cliente = JSON.parse(sessionStorage.getItem('cliente'));
      const token = sessionStorage.getItem('token');

      if (!cliente || !token) {
        setError('Cliente não autenticado.');
        setLoading(false);
        return;
      }

      try {
        const response = await axios.get(`http://localhost:3030/cliente/${id}/reservas`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
          params: {
            ClienteID: cliente.id,
          },
        });

        if (Array.isArray(response.data)) {
          setReservations(response.data); 
        } else {
          setError('Formato de dados inesperado recebido da API.');
          console.error('Formato de dados inesperado:', response.data);
        }
      } catch (error) {
        setError('Erro ao carregar as reservas. Tente novamente mais tarde.');
        console.error('Erro ao carregar as reservas:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchReservations();
  }, [id]); 

  const handleDeleteReservation = async (id) => {
    const cliente = JSON.parse(sessionStorage.getItem('cliente'));
    const token = sessionStorage.getItem('token');

    if (!cliente || !token) {
      setError('Cliente não autenticado.');
      return;
    }

    try {
      await axios.delete(`http://localhost:3030/cliente/reserva/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        params: {
          ClienteID: cliente.id,
        },
      });

      const updatedReservations = reservations.filter(reserva => reserva.id !== id);
      setReservations(updatedReservations);
    } catch (error) {
      setError('Erro ao deletar a reserva. Tente novamente mais tarde.');
      console.error('Erro ao deletar a reserva:', error);
    }
  };

  return (
    <main className="min-h-screen flex flex-col">
      <div className="flex-grow flex items-center justify-center relative">
        <img src={bgReservas} alt="Background" className='w-full h-full brightness-50 blur-sm object-cover absolute inset-0 z-[-1]'/>
        <div className="w-full max-w-2xl p-8 bg-neve rounded-md shadow-md font-poppins relative z-[1]">
          <h1 className="text-3xl font-semibold mb-6 text-center">Minhas Reservas</h1>
          {loading ? (
            <p className="text-center">Carregando...</p>
          ) : error ? (
            <p className="text-center text-red-600">{error}</p>
          ) : reservations.length > 0 ? (
            reservations.map(reserva => (
              <div key={reserva.id} className="p-4 mb-4 bg-white rounded-md shadow-md">
                <h2 className="text-xl font-semibold">{reserva.restaurante?.nome || 'Nome não disponível'}</h2>
                <p><strong>Data:</strong> {new Date(reserva.Data).toLocaleDateString()}</p>
                <p><strong>Horário:</strong> {reserva.Horario}</p>
                <p><strong>Número de Pessoas:</strong> {reserva.NumeroPessoas}</p>
                <button
                  className="px-4 py-2 mt-2 bg-red-600 text-white rounded-md hover:bg-red-500"
                  onClick={() => handleDeleteReservation(reserva.id)}
                >
                  Deletar Reserva
                </button>
              </div>
            ))
          ) : (
            <p className="text-center">Você não possui reservas.</p>
          )}
        </div>
      </div>
    </main>
  );
};

export default MinhasReservas;
