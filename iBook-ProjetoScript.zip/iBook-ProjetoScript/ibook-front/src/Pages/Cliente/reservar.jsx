import React, { useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const Reservar = () => {
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [people, setPeople] = useState(1);
  const [confirmation, setConfirmation] = useState(null); 
  const { id } = useParams();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const cliente = JSON.parse(sessionStorage.getItem('cliente'));
    const token = sessionStorage.getItem('token');
    console.log(time);
    try {
      const response = await axios.post(
        'http://localhost:3030/cliente/reserva',
        {
          ClienteID: cliente.id, 
          RestauranteID: id, 
          Data: date,
          Horario: time,
          NumeroPessoas: people,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setConfirmation(response.data);
    } catch (error) {
      console.error('Erro ao fazer a reserva:', error);
      setConfirmation({ error: 'Falha ao fazer a reserva. Tente novamente mais tarde.' });
    }
  };

  return (
    <main className="bg-gray-200 min-h-screen flex flex-col items-center justify-center font-poppins p-8">
      <h1 className="text-3xl font-semibold mb-6">Faça sua Reserva</h1>
      {!confirmation ? (
        <form className="bg-white p-6 rounded-md shadow-lg w-full max-w-md" onSubmit={handleSubmit}>
          <div className="flex flex-col mb-4">
            <label htmlFor="date" className="mb-2 font-medium">Data</label>
            <input
              type="date"
              id="date"
              className="border p-2 rounded-md outline-none"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
            />
          </div>
          <div className="flex flex-col mb-4">
            <label htmlFor="time" className="mb-2 font-medium">Horário</label>
            <input
              type="time"
              id="time"
              className="border p-2 rounded-md outline-none"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              required
            />
          </div>
          <div className="flex flex-col mb-4">
            <label htmlFor="people" className="mb-2 font-medium">Número de Pessoas</label>
            <input
              type="number"
              id="people"
              className="border p-2 rounded-md outline-none"
              value={people}
              onChange={(e) => setPeople(e.target.value)}
              min="1"
              required
            />
          </div>
          <button type="submit" className="px-8 py-2 w-full rounded-md bg-red-600 hover:bg-red-500 text-white">Reservar</button>
        </form>
      ) : (
        <div className="bg-white p-6 rounded-md shadow-md w-full max-w-md text-center">
          {confirmation.error ? (
            <>
              <h2 className="text-2xl font-semibold mb-4 text-red-600">Erro na Reserva</h2>
              <p>{confirmation.error}</p>
            </>
          ) : (
            <>
              <h2 className="text-2xl font-semibold mb-4">Reserva Confirmada!</h2>
              <p>Data: {confirmation.Data}</p>
              <p>Horário: {confirmation.Horario}</p>
              <p>Número de Pessoas: {confirmation.NumeroPessoas}</p>
            </>
          )}
          <button
            className="px-8 py-2 mt-6 rounded-md bg-red-600 hover:bg-red-500 text-white"
            onClick={() => setConfirmation(null)}
          >
            Fazer Nova Reserva
          </button>
        </div>
      )}
    </main>
  );
};

export default Reservar;
