import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Perfil = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [Nome, setNome] = useState('');
  const [Email, setEmail] = useState('');
  const [Telefone, setTelefone] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProfile = async () => {
      const token = sessionStorage.getItem('token');
      const cliente = JSON.parse(sessionStorage.getItem('cliente'));

      try {
        const response = await axios.get(`http://localhost:3030/cliente/${cliente.id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const { Nome, Email, Telefone } = response.data;
        setNome(Nome);
        setEmail(Email);
        setTelefone(Telefone);
        setIsLoading(false);
      } catch (error) {
        setError('Erro ao buscar informações do perfil. Cliente não logado!');
        setIsLoading(false);
      }
    };

    fetchProfile();
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    const token = sessionStorage.getItem('token');
    const cliente = JSON.parse(sessionStorage.getItem('cliente'));

    try {
      await axios.put(
        `http://localhost:3030/cliente/${cliente.id}`,
        {
          Nome: Nome,
          Email: Email,
          Telefone: Telefone,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setIsEditing(false);
    } catch (error) {
      setError('Erro ao salvar as informações do perfil.');
    }
  };

  if (isLoading) {
    return <div>Carregando...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <main className="min-h-screen bg-gray-100 p-8 font-poppins">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h1 className="text-3xl font-semibold mb-4">Olá, {Nome}</h1>
          {isEditing ? (
            <form onSubmit={handleSave} className="mb-4">
              <div className="mb-4">
                <label htmlFor="name" className="block mb-1 text-sm font-medium text-gray-700">Nome</label>
                <input
                  type="text"
                  id="name"
                  className="border p-2 rounded-md outline-none w-full"
                  value={Nome}
                  onChange={(e) => setNome(e.target.value)}
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="email" className="block mb-1 text-sm font-medium text-gray-700">Email</label>
                <input
                  type="email"
                  id="email"
                  className="border p-2 rounded-md outline-none w-full"
                  value={Email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="phone" className="block mb-1 text-sm font-medium text-gray-700">Telefone</label>
                <input
                  type="tel"
                  id="phone"
                  className="border p-2 rounded-md outline-none w-full"
                  value={Telefone}
                  onChange={(e) => setTelefone(e.target.value)}
                  required
                />
              </div>
              <div className="flex justify-end">
                <button type="submit" className="px-8 py-2 rounded-md bg-gray-500 hover:bg-gray-400 text-white">Salvar</button>
                <button type="button" onClick={() => setIsEditing(false)} className="ml-4 px-6 py-2 rounded-md bg-red-500 hover:bg-red-400 text-white">Cancelar</button>
              </div>
            </form>
          ) : (
            <>
              <div className="mb-4">
                <div className="border-b-2 border-gray-200 pb-2 mb-2">
                  <p className="text-sm text-gray-600">Nome:</p>
                  <p className="text-lg font-medium">{Nome}</p>
                </div>
                <div className="border-b-2 border-gray-200 pb-2 mb-2">
                  <p className="text-sm text-gray-600">Email:</p>
                  <p className="text-lg font-medium">{Email}</p>
                </div>
                <div className="border-b-2 border-gray-200 pb-2">
                  <p className="text-sm text-gray-600">Telefone:</p>
                  <p className="text-lg font-medium">{Telefone}</p>
                </div>
              </div>
              <button onClick={() => setIsEditing(true)} className="px-8 py-2 rounded-md bg-red-500 hover:bg-red-400 text-white mb-4">Editar Perfil</button>
            </>
          )}
        </div>
      </div>
    </main>
  );
};

export default Perfil;
