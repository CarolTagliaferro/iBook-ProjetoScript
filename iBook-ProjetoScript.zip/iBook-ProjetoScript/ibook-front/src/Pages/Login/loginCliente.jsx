import React, { useState } from 'react';
import bgImage from "../../images/bgImage.jpg";
import {  useNavigate } from 'react-router-dom';
import axios from 'axios'

const LoginCliente = () => {
  const [isLogin, setIsLogin] = useState(true)
  const navigate = useNavigate()
  const [Email, setEmail] = useState('')
  const [Senha, setSenha] = useState('')
  const [Nome, setNome] = useState('');
  const [CPF, setCpf] = useState('');
  const [Telefone, setTelefone] = useState('');
  const [error, setError] = useState('')


  const handleLogin = async (e) => {
    e.preventDefault()
    try {
      const response = await axios.post('http://localhost:3030/cliente/login', {Email, Senha})
      console.log(response)
      if(response.status === 200){
        console.log(response.data)
        const token = response.data.token
        sessionStorage.setItem('token', token)
        const cliente = response.data.cliente
        sessionStorage.setItem('cliente', JSON.stringify(cliente))
        console.log('Login efetuado com sucesso')
        navigate('/')
      } else {
        setError ('Email ou senha invalidos')
      }

    } catch (error){
      console.error('Erro no login!', error)
    }
  }  
       
  const handleCadastro = async (e) => {
    e.preventDefault();
    const cliente = {
      Nome,
      Email,
      CPF,
      Telefone,
      Senha
    }
    console.log(cliente)
    try {
      const response = await axios.post('http://localhost:3030/cliente', cliente);

      if (response.status === 200) {
        const token = response.data.token;
        sessionStorage.setItem('token', token);
        const cliente = response.data.cliente;
        sessionStorage.setItem('cliente', JSON.stringify(cliente));
        console.log('Cadastro efetuado com sucesso');
      } else {
        setError('Erro ao cadastrar. Verifique os dados informados.');
      }

    } catch (error) {
      console.error('Erro ao cadastrar!', error);
      setError('Erro ao tentar cadastrar. Por favor, tente novamente mais tarde.');
      setTimeout(() => setError(null), 2000);
    }
  };
     
    

  const toggleForm = () => {
    setIsLogin(!isLogin);
  };

  return (
    <main className='min-h-screen flex flex-col'>
      <div className="flex-grow flex items-center justify-center relative">
        <img src={bgImage} alt="Background" className='w-full h-full brightness-50 blur-sm object-cover absolute inset-0 z-[-1]'/>
        <div className='p-8 bg-white opacity-90 rounded-md shadow-md lg:w-full max-w-md font-poppins relative z-[1]'> 
          <h1 className='font-semibold text-2xl'>{isLogin ? 'Login' : 'Registrar'}</h1>
          <form className='mt-6'>
            {error && <p>{error}</p>}
            {isLogin ? (
              <>
                <div className='flex flex-col'>
                  <label>Email</label>
                  <input type="email" placeholder='email@email.com' id='email' value={Email} onChange={(e) => setEmail(e.target.value)} className='border p-2 rounded-md outline-none mt-1'/>
                </div>
                <div className='flex flex-col mt-3'>
                  <label>Senha</label>
                  <input type="password" placeholder='Digite a senha' id='password' value={Senha} onChange={(e) => setSenha(e.target.value)} className='border p-2 rounded-md outline-none mt-1'  />
                </div>
                <button onClick={handleLogin} className='px-8 py-2 w-full rounded-md bg-red-600 hover:bg-red-500 text-white mt-5'>Entrar</button>
                <div className='text-center pt-6'>
                  <p>Não tem uma conta? <span className='text-red-600 hover:underline cursor-pointer' onClick={toggleForm}>Cadastre-se</span></p>
                </div>
              </>
            ) : (
              <>
               <div className='flex flex-col'>
                  <label>Nome</label>
                  <input type="text" placeholder='Digite o nome' value={Nome} onChange={(e) => setNome(e.target.value)} className='border p-2 rounded-md outline-none mt-1'/>
                </div>
                <div className='flex flex-col mt-3'>
                  <label>Email</label>
                  <input type="email" placeholder='email@email.com' value={Email} onChange={(e) => setEmail(e.target.value)} className='border p-2 rounded-md outline-none mt-1'/>
                </div>
                <div className='flex flex-col mt-3'>
                  <label>CPF</label>
                  <input type="text" placeholder='Digite seu CPF' value={CPF} onChange={(e) => setCpf(e.target.value)} className='border p-2 rounded-md outline-none mt-1'  />
                </div>
                <div className='flex flex-col mt-3'>
                  <label>Telefone</label>
                  <input type="text" placeholder='(00) 00000-0000' value={Telefone} onChange={(e) => setTelefone(e.target.value)} className='border p-2 rounded-md outline-none mt-1'  />
                </div>
                <div className='flex flex-col mt-3'>
                  <label>Senha</label>
                  <input type="password" placeholder='Digite a senha' value={Senha} onChange={(e) => setSenha(e.target.value)} className='border p-2 rounded-md outline-none mt-1'  />
                </div>
                <button type="submit" onClick={handleCadastro} className='px-8 py-2 w-full rounded-md bg-red-600 hover:bg-red-500 text-white mt-5'>Registrar</button>
                <div className='text-center pt-6'>
                  <p>Já tem uma conta? <span className='text-red-600 hover:underline cursor-pointer' onClick={toggleForm}>Entre</span></p>
                </div>
              </>
            )}
          </form>
        </div>
      </div>
    </main>
  );
};

export default LoginCliente;
