import React from 'react';
import {  Route, Routes } from 'react-router-dom';
import Home from '../Pages/Home/home';
import LoginCliente from '../Pages/Login/loginCliente';
import RestaurantDetails from '../Pages/Restaurante/restaurantDetails';
import Reservar from '../Pages/Cliente/reservar';
import Reservas from '../Pages/Cliente/reservas';
import Perfil from '../Pages/Cliente/perfil';

const AppRouter = () => {
  return (
    
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<LoginCliente />} />
        <Route path="/restauranteMenu/:id" element={<RestaurantDetails />} />
        <Route path='/reservar/:id' element={<Reservar/>}/>
        <Route path='cliente/:id/reservas' element={<Reservas/>}/>
        <Route path='/perfil' element={<Perfil/>}/>
      </Routes>
    
  );
}

export default AppRouter;
